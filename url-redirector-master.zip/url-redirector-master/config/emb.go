package config

import _ "embed"

//go:embed redirect.json
var Data []byte
