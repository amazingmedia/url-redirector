# url-redirector
A serverless url redirctoron vercel powered by golang
